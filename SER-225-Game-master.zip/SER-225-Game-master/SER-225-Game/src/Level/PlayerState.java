package Level;

// This enum represents different states the Player can be in
public enum PlayerState {
    STANDING, WALKING, JUMPING, CROUCHING
}
