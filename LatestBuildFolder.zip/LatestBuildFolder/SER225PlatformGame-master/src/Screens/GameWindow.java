package Screens;

import javax.swing.*;
import Engine.GamePanel;
import Engine.ScreenManager;


/*
 * The JFrame that holds the GamePanel
 * Just does some setup and exposes the gamePanel's screenManager to allow an external class to setup their own content and attach it to this engine.
 */
public class GameWindow {
	private JFrame gameWindow;
	private GamePanel gamePanel;
	public PlayLevelScreen pLS;
	public static int width;
    public static int height;
	public static final int widthS = 800;
    public static final int heightS = 605;
    public static final int widthM = 950;
    public static final int heightM = 705;
    public static final int widthL = 1100;
    public static final int heightL = 710;
    
    public void setBoundsSmall() 
    {
    	width = widthS;
    	height = heightS;
    }
    public void setBoundsMedium() 
    {
    	width = widthM;
    	height = heightM;
    }
    public void setBoundsLarge() 
    {
    	width = widthL;
    	height = heightL;
    }
	public GameWindow() {
		gameWindow = new JFrame("Game");
		gamePanel = new GamePanel();
		gamePanel.setFocusable(true);
		gamePanel.requestFocusInWindow();
		gameWindow.setContentPane(gamePanel);
		gameWindow.setResizable(false);
		setBoundsSmall();
		/*if(pLS.screenS == true && pLS.screenM == false && pLS.screenL == false) 
		{
			gameWindow.setSize(Config.GAME_WINDOW_WIDTH, Config.GAME_WINDOW_HEIGHT);
		}
		else if(pLS.screenS == false && pLS.screenM == true && pLS.screenL == false) 
		{
			gameWindow.setSize(Config.GAME_WINDOW_WIDTHM, Config.GAME_WINDOW_HEIGHTM);
		}
		else if(pLS.screenS == false && pLS.screenM == false && pLS.screenL == true) 
		{
			gameWindow.setSize(Config.GAME_WINDOW_WIDTHL, Config.GAME_WINDOW_HEIGHTL);
		}*/
		//gameWindow.setSize(Config.GAME_WINDOW_WIDTH, Config.GAME_WINDOW_HEIGHT);
		gameWindow.setSize(width, height);
		
		

		gameWindow.setLocationRelativeTo(null);
		gameWindow.setVisible(true);
		gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // it'd be nice if this actually worked more than 1/3rd of the time
		gamePanel.setupGame();
	}

	// triggers the game loop to start as defined in the GamePanel class
	public void startGame() {
		gamePanel.startGame();
		
	}

	public ScreenManager getScreenManager() {
		return gamePanel.getScreenManager();
	}
}
