package Engine;

import Utils.Colors;

import java.awt.*;

/*
 * This class holds some constants like window width/height and resource folder locations
 * Tweak these as needed, they shouldn't break anything (keyword shouldn't).
 */
public class Config {
    public static final int FPS = 100;
    public static final String RESOURCES_PATH = "Resources/";
    public static final String MAP_FILES_PATH = "MapFiles/";
    public static final int GAME_WINDOW_WIDTH = 800;
    public static final int GAME_WINDOW_HEIGHT = 605;
    public static final int GAME_WINDOW_WIDTHM = 950;
    public static final int GAME_WINDOW_HEIGHTM = 705;
    public static final int GAME_WINDOW_WIDTHL = 1100;
    public static final int GAME_WINDOW_HEIGHTL = 710;
    public static final Color TRANSPARENT_COLOR = Colors.MAGENTA;

    // prevents Config from being instantiated -- it's my way of making a "static" class like C# has
    private Config() { }
    
   /* public void setScreenSmall(int width, int Height) 
    {
    	width = GAME_WINDOW_WIDTH;
    	Height = GAME_WINDOW_HEIGHT;
    }
    public void setScreenMedium(int width, int Height) 
    {
    	width = GAME_WINDOW_WIDTHM;
    	Height = GAME_WINDOW_HEIGHTM;
    }
    public void setScreenLarge(int width, int Height) 
    {
    	width = GAME_WINDOW_WIDTHL;
    	Height = GAME_WINDOW_HEIGHTL;
    }*/
}
