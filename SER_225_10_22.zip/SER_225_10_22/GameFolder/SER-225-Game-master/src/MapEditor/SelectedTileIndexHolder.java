package MapEditor;

public class SelectedTileIndexHolder {
    private int selectedTileIndex;

    public int getSelectedTileIndex() {
        return selectedTileIndex;
    }

    public void setSelectedTileIndex(int selectedTileIndex) {
        this.selectedTileIndex = selectedTileIndex;
    }
}
